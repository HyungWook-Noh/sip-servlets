/**
 * 
 * (c) 2007-2008 BEA Systems, Inc., or its suppliers, as applicable. 
 * All rights reserved. 
 *
 * Used to declare sip application 
 */
@javax.servlet.sip.annotation.SipApplication( 
	name = "com.bea.sipservlet.tck.apps.spectestapp.uac",
	displayName = "Spec Assertion Test UAC Application",
	mainServlet = "UacMainServlet")
package com.bea.sipservlet.tck.apps.spec.uac;
