/**
 *
 * (c) 2007-2008 BEA Systems, Inc., or its suppliers, as applicable.
 * All rights reserved.
 *
 * Used to declare sip application
 */
@javax.servlet.sip.annotation.SipApplication(
	name = "AR-SuburiRegion",
	displayName = "Application Router Test Application 04",
	mainServlet = "JSR289.TCK.AppRouter.SuburiRegionServlet")
package com.bea.sipservlet.tck.apps.spec.ar.suburiregion;
