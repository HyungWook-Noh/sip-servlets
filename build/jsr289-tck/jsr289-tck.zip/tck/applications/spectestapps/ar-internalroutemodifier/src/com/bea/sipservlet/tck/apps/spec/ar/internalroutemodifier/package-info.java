/**
 *
 * (c) 2007-2008 BEA Systems, Inc., or its suppliers, as applicable.
 * All rights reserved.
 *
 * Used to declare sip application
 */
@javax.servlet.sip.annotation.SipApplication(
	name = "AR-InternalRouteModifier",
	displayName = "Application Router Test Application 02",
	mainServlet = "JSR289.TCK.AppRouter.InternalRouteModifierServlet")
package com.bea.sipservlet.tck.apps.spec.ar.internalroutemodifier;
