/**
 *
 * (c) 2007-2008 BEA Systems, Inc., or its suppliers, as applicable.
 * All rights reserved.
 *
 * Used to declare sip application
 */
@javax.servlet.sip.annotation.SipApplication(
	name = "AR-Continue",
	displayName = "Application Router Test Application 01",
	mainServlet = "JSR289.TCK.AppRouter.ContinueServlet")
package com.bea.sipservlet.tck.apps.spec.ar.cont;
