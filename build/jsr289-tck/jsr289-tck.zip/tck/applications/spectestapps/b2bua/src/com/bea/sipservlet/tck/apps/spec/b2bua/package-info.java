/**
 * 
 * (c) 2007-2008 BEA Systems, Inc., or its suppliers, as applicable. 
 * All rights reserved. 
 *
 * Used to declare sip application 
 */
@javax.servlet.sip.annotation.SipApplication( 
	name = "com.bea.sipservlet.tck.apps.spectestapp.b2bua",
	displayName = "Spec Assertion Test B2BUA Application",
	mainServlet = "B2buaMainServlet")
package com.bea.sipservlet.tck.apps.spec.b2bua;
