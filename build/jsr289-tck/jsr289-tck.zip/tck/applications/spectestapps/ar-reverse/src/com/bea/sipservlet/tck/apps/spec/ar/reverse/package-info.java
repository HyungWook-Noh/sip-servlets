/**
 *
 * (c) 2007-2008 BEA Systems, Inc., or its suppliers, as applicable.
 * All rights reserved.
 *
 * Used to declare sip application
 */
@javax.servlet.sip.annotation.SipApplication(
	name = "AR-Reverse",
	displayName = "Application Router Test Application 03",
	mainServlet = "JSR289.TCK.AppRouter.ReverseServlet")
package com.bea.sipservlet.tck.apps.spec.ar.reverse;
