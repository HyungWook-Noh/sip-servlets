/**
 * 
 * (c) 2007-2008 BEA Systems, Inc., or its suppliers, as applicable. 
 * All rights reserved. 
 *
 * Used to declare sip application 
 */
@javax.servlet.sip.annotation.SipApplication( 
	name = "com.bea.sipservlet.tck.apps.apitestapp",
	displayName = "API Assertion Test Application",
	mainServlet = "ApiTestMainServlet")
package com.bea.sipservlet.tck.apps.api;
